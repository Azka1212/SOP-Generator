from django.urls import path
from . import views

urlpatterns = [
    path('login/', views.login_view, name='login'),
    path('signup/', views.signup_view, name='signup'),  # Add this for signup page
    path('ai-sop/', views.ai_sop_page, name='ai_sop_page'),  # URL for AI SOP page 
    path('generate-sop/', views.generate_sop, name='generate_sop'),  # Add this for generate_sop 
    path('test-openai/', views.test_openai, name='test_openai'),  # Test OpenAI API
]
