from django.db import models

# Create your models here.


class SOPRequest(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20)
    university = models.CharField(max_length=100)
    course = models.CharField(max_length=100)
    why_university = models.TextField()
    additional_info = models.TextField(blank=True)
    resume = models.FileField(upload_to='resumes/')
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name
