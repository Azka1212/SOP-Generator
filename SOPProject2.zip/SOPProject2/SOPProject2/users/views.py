from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages
from django.contrib.auth.decorators import login_required
import requests
from django.http import JsonResponse

import openai
from django.shortcuts import render, redirect
from .models import SOPRequest
from django.http import HttpResponse
import fitz  # PyMuPDF

# OpenAI API Key
openai.api_key = ""


def login_view(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('ai_sop_page')  # Redirect to AI SOP page after login
        else:
            messages.error(request, 'Invalid username or password')
    
    return render(request, 'users/login.html')

def test_openai(request):
    # Basic prompt for testing with chat-based API
    messages = [
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "Write a short story about a dragon and a knight."}
    ]

    try:
        # Call OpenAI Chat API to generate a response
        response = openai.ChatCompletion.create(
            model="gpt-4o-mini",  # Chat-based GPT model
            messages=messages,
            max_tokens=100  # Limit the length of the response
        )
        generated_text = response.choices[0].message['content'].strip()

        # Return the generated text in the response
        return HttpResponse(f"<h1>Test OpenAI Chat API Response</h1><pre>{generated_text}</pre>")

    except openai.error.OpenAIError as e:
        # Handle API errors and return a 500 response
        return HttpResponse(f"Error with OpenAI API: {str(e)}", status=500)
    
def signup_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Account created successfully! Please log in.')
            return redirect('login')  # Redirect to login page after signup
        else:
            messages.error(request, 'There was an error with your registration')
    else:
        form = UserCreationForm()

    return render(request, 'users/signup.html', {'form': form})

def generate_sop(request):
    if request.method == 'POST':
        # Get user data from form
        name = request.POST.get('name')
        email = request.POST.get('email')
        phone = request.POST.get('phone')
        university_name = request.POST.get('universityName')
        course_name = request.POST.get('courseName')
        why_university = request.POST.get('whyUniversity')
        additional_info = request.POST.get('additionalInfo')
        
        # Ensure required fields are present
        if not (name and email and phone and university_name and course_name and why_university):
            return JsonResponse({"error": "Missing required fields"}, status=400)

        # Get uploaded PDF file (resume)
        resume = request.FILES.get('resume')
        resume_text = ""

        if resume and resume.name.endswith('.pdf'):
            # Extract text from the PDF
            try:
                print(f"Received file: {resume.name}")
                with fitz.open(stream=resume.read(), filetype="pdf") as pdf_document:
                    for page_num in range(len(pdf_document)):
                        page = pdf_document.load_page(page_num)
                        resume_text += page.get_text()

                # print(f"Resume content length: {len(resume_text)}")
                # print(f"Extracted Resume Text:\n{resume_text}")
            except Exception as e:
                return JsonResponse({"error": f"Failed to extract text from PDF: {str(e)}"}, status=500)

        # Special handling for Canada visa
        if 'canada' in university_name.lower():
            visa_message = """
            To,
            The Visa Officer,
            The Canadian High Commission, New Delhi.
            Subject: Statement of purpose for the application of Canada study permit visa
            """
        else:
            visa_message = ""

        # Create the prompt for the OpenAI Chat API
        prompt = f"""
        I need an SOP for {name} applying to {university_name} for {course_name}. Here are the details:
        - Why do they want to apply: {why_university}
        - Additional information: {additional_info}
        - Resume (extracted text): {resume_text}

        Highlight relevant experience and achievements from resume
        """

        messages = [
            {"role": "system", "content": "You are a helpful assistant that writes Statement of Purpose."},
            {"role": "user", "content": prompt}
        ]

        try:
            # Call OpenAI Chat API to generate the SOP
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=messages,
                max_tokens=500
            )
            generated_sop = response.choices[0].message['content'].strip()

            # Combine with visa message if applicable
            full_sop = f"{visa_message}\n\n{generated_sop}"

            # Return the generated SOP as JSON
            return JsonResponse({"sop": full_sop})

        except openai.error.OpenAIError as e:
            return JsonResponse({"error": str(e)}, status=500)

    return JsonResponse({"error": "Invalid request method"}, status=400)

@login_required
def ai_sop_page(request):
    return render(request, 'users/ai_sop_page.html')